Microsoft SharePoint 2007 (sp2007) AUTOMATED BENCHMARK USER GUIDANCE

JUNE 15, 2011

Notice: This technical data was produced for the U.S. Government under
Contract No. W15P7T-11-C-F600, and is subject to the Rights in Technical
Data-Noncommercial Items clause at DFARS 252.227-7013 (NOV 1995)
� 2011 The MITRE Corporation. All Rights Reserved.

The sp2007 SCAP bundle should be installed on your Windows 2003 system
running Microsoft SharePoint 2007.  The XCCDF Interpreter can be used to
run the sp2007 Benchmark. The XCCDF Interpreter requires JAVA 1.6 or higher to 
be installed on the machine.

=================================================================================

The sp2007 SCAP Bundle contains the following files: 

a. sp2007
	i.   sp2007-xccdf.xml
	ii.  sp2007-oval.xml
	iii. sp2007-ocil.xml
	iv.  sp2007-cpe-dictionary.xml
	v.   sp2007-cpe-oval.xml
	

b. Documentation

	i.  sp2007.guide.html   (Human readable Benchmark document)
	ii. READ_ME_sp2007.txt  (Automated Benchmark User Guidance)
	
================================================================================

Instructions Overview:

1. Building the SharePoint OVAL Interpreter Branch
2. Running the Benchmark with the XCCDF Interpreter

When this guide was originally developed, there were not sufficient OVAL probes
to test SharePoint security settings. While it was not possible for all probes 
to be implemented, the OVAL team developed special SharePoint probes to assess 
the OVAL checks currently used in this guide.

In order to use an OVAL Interpreter with the SharePoint branch, it must be 
built from source. To do this, several libraries (PCRE, Xerces, Xalan, and 
Libgcrypt) must also be built. The instructions for building the OVAL Interpreter 
follow. The next step after building the OVAL Interpreter is to reference it 
from the XCCDF Interpreter, so that the packaged OVAL interpreter is not used. 
The benchmark will then be run from the XCCDF Interpreter, referencing the OVAL 
Interpreter with the SharePoint Branch.

=================================================================================================

BUILDING THE OVAL INTERPRETER WITH SHAREPOINT BRANCH

1. Download the Instructions for building the OVAL Interpreter from SourceForge:

   http://ovaldi.svn.sourceforge.net/viewvc/ovaldi/branches/sharepoint/docs/build.win32.txt?revision=930&view=markup
	
2. Download the Instructions for building the XERCES and XALAN libraries from SourceForge:

   http://ovaldi.svn.sourceforge.net/viewvc/ovaldi/branches/sharepoint/docs/build.xerces.xalan.win32.txt?revision=930&view=markup

3. Follow the OVAL Interpreter Build Instructions, referencing the XERCES and XALAN Build 
   Instructions when building the Xerces and Xalan libraries. Below are a few notes to 
   add to these instructions. Please read the following notes before beginning the 
   OVAL/XERCES & XALAN instructions.
	
		a) When downloading the OVAL Interpreter Source Distribution, do not 
		   download the standard OVAL zip on SourceForge. Download the GNU 
		   Tarball from this location:
			
		   http://ovaldi.svn.sourceforge.net/viewvc/ovaldi/branches/sharepoint/
			
		   This Source Distribution contains the SharePoint branch.
			
		   Use a gzip application that runs on Windows 2003 to unzip the tarball, 
		   such as Power Archiver (http://www.powerarchiver.com/download/) or 
		   WinZip (http://www.winzip.com/downwz.htm).
			
		b) When building the Xerces library and setting the C++ Language properties 
		   option (Section II, Step 5-6 of the Xerces/Xalan Instructions), make 
		   sure that all projects EXCEPT the "all" project are selected. If the 
		   "all" project is selected, the C++ folder will not appear under 
		   "Configuration Properties".
			
		c) Take special care when editing the make files. A small mistake may 
		   result in errors in the builds.
		
		d) After downloading and installing the Libgcrypt Library and adding the 
		   appropriate directories to the files search paths in Visual Studio, 
		   perform the following steps:

			i) Open a MSVC x86 command prompt:
				START > All Programs > Microsoft Visual Studio 2008 > Visual Studio Tools > Visual Studio Command Prompt
			
			ii) CD to your Libgcrypt lib directory, and run:
				lib /machine:x86 /def:libgcrypt.def
			
			iii) That will generate libgcrypt.lib. Unless they are already there,
			     copy libgrypt.dll into the 'bin' subdirectory of your libgcrypt 
			     install directory, and libgcrypt.lib into the 'lib' subdirectory.

		e) When the OVAL Interpreter is built, choose the "Release" option by going 
		   to Project > Properties > Configuration Manager and selecting "Release" as 
		   the "Active Solution Configuration". After building, the executable 
		   (ovaldiD.exe) will be found in:

		   {Install Directory}\ovaldi-sharepoint\sharepoint\project\Win32\VC8\Debug

		   The executable will be found here regardless of whether it is a Release or a Debug Build.
			
		f) In order for the OVAL Interpreter to run, copy the following files into the 
		   directory containing ovaldiD.exe:
		
			-pcre3.dll from {Install Directory}\GnuWin32\bin
			-libgcrypt-11.dll from {Install Directory}\gpg-w32-dev-20100713\gpg-w32-dev-20100713\bin
			-libgpg-error-0.dll from {Install Directory}\gpg-w32-dev-20100713\gpg-w32-dev-20100713\bin
			-Xalan-C_1_10.dll from $(XALANCROOT)\Build\Win32\VC7.1\Release
			-XalanMessages_1_10.dll from $(XALANCROOT)\Build\Win32\VC7.1\Release
			-xerces-c_2_8.dll from $(XERCESCROOT)\Build\Win32\VC8\Release 
					
		   Additionally, copy the "xml" folder and its contents (location: {Install Directory}\ovaldi-sharepoint\sharepoint\xml)
		   to the directory containing ovaldiD.exe.
				
		   Change the name of "libgcrypt-11.dll" to "libgcrypt.dll".
			
4. Test that the OVAL Interpreter is built properly by dropping the OVAL file in this bundle 
   into the directory containing ovaldiD.exe, and running the following command:
	
	ovaldiD.exe -m -a xml -o sp2007-oval.xml
		
   Assuming that SharePoint is installed and no checks result in "Not Applicable" and results 
   are displayed for all OVAL checks, the OVAL Interpreter SharePoint build is running correctly.
					
=================================================================================================

RUNNING THE BENCHMARK WITH THE XCCDF INTERPRETER

1. Download the XCCDF Interpreter from SourceForge:
   http://sourceforge.net/projects/xccdfexec/

2. Unzip and install the XCCDF Interpreter, as directed by its README.txt.

3. Navigate to the XCCDF Interpreter directory.  For example: 
   cd /xccdf_interpreter_1.1.4_build_11-bin 
	
   Unzip the sp2007 SCAP Bundle to this directory
   
4. Open the xccdf_interpreter.proprerties file. After "oval.dir", enter the full path name for 
   the directory of the OVAL interpreter built in the above steps. Then, replace every "/" with 
   "//". This is a necessary step since "/" is an escape character in Java. If single slashes are 
   used, they will be erased after running the XCCDF Interpreter and the OVAL interpreter will 
   never be reached. For example,

    "C\:\ovaldi-sharepoint\project\Win32\VC8\Debug"

    becomes 

    "C\:\\ovaldi-sharepoint\\project\\Win32\\VC8\\Debug"

    After "oval.bin", enter the name of the interpreter executable. This should be "ovaldiD.exe".

5. To run the interpreter, type the following:

   java -jar xccdfexec.jar sp2007-xccdf.xml -c sp2007-cpe-oval.xml -C sp2007-cpe-dictionary.xml -P Share-13-1

6. When prompted with the OCIL Interpreter, answer each questionnaire, save the results, and exit.

7. The results of the tests will be displayed on the screen and in an output file under the 
   results directory. 

8. A result of PASS indicates that the test passed, a result of FAIL indicates that the test 
   failed and a setting may need to be adjusted.  You can review the recommendations how-to 
   section in the guide (sp2007.guide.html) to adjust any settings. A result of "NOT CHECKED" 
   means that the recommendation's OCIL questionnaire was not answered.

=================================================================================================
